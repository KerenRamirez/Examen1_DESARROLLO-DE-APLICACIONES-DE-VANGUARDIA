using System;
using System.Collections.Generic;
using FoodTrack.Domain;
using FoodTrack.Ports;

namespace FoodTrack.Application
{
    public class OrderService
    {
        private readonly IOrderRepository _orders;
        private readonly IFoodTruckRepository _trucks;
        private readonly IEventLogRepository _events;

        public OrderService(IOrderRepository orders, IFoodTruckRepository trucks, IEventLogRepository events)
        {
            _orders = orders; _trucks = trucks; _events = events;
        }

        public Order CreateOrder(Guid foodTruckId, IEnumerable<Item> items)
        {
            var truck = _trucks.Get(foodTruckId) ?? throw new ArgumentException("FoodTruck no encontrado");
            var order = new Order(Guid.NewGuid(), truck.Id, items);
            _orders.Add(order);
            _events.Add(new EventLog(order.Id, OrderState.Creada, OrderState.Creada));
            return order;
        }

        public Order? GetOrder(Guid id) => _orders.Get(id);

        public void ChangeOrderState(Guid orderId, OrderState nuevo)
        {
            var order = _orders.Get(orderId) ?? throw new ArgumentException("Order no encontrada");
            var (anterior, actual) = order.CambiarEstado(nuevo);
            order.RecalcularTotal();
            _orders.Update(order);
            _events.Add(new EventLog(order.Id, anterior, actual));
        }

        public IEnumerable<Order> ListOrdersForFoodTruck(Guid foodTruckId) => _orders.ListByFoodTruck(foodTruckId);

        public IEnumerable<EventLog> GetEventLogForOrder(Guid orderId) => _events.GetForOrder(orderId);
    }
}
