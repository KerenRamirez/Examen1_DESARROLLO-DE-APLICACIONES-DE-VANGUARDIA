# FoodTrack API (Minimal .NET)

Proyecto estructurado con separación de capas y repositorios en memoria.

## Requisitos
- .NET 8 SDK (o .NET 7 se puede adaptar cambiando TargetFramework en el csproj)

## Ejecutar localmente
```bash
dotnet restore
dotnet run
```

La API quedará escuchando en el puerto que muestre la consola (por defecto 5000/5001).

## Endpoints disponibles
- POST /foodtrucks
- GET  /foodtrucks
- POST /orders
- GET  /orders/{id}
- PUT  /orders/{id}/state
- GET  /foodtrucks/{id}/orders
- GET  /orders/{id}/events
