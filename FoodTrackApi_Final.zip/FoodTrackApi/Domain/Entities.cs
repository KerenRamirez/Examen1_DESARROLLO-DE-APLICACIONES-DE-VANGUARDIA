using System;
using System.Collections.Generic;
using System.Linq;

namespace FoodTrack.Domain
{
    public enum OrderState { Creada, EnPreparacion, Lista, Entregada }

    public record Item(string Nombre, decimal Precio, int Cantidad);

    public class FoodTruck
    {
        public Guid Id { get; init; }
        public string Nombre { get; init; }
        public string UbicacionActual { get; set; }

        public FoodTruck(Guid id, string nombre, string ubicacion)
        {
            Id = id; Nombre = nombre; UbicacionActual = ubicacion;
        }
    }

    public class Order
    {
        public Guid Id { get; init; }
        public Guid FoodTruckId { get; init; }
        public List<Item> Items { get; } = new();
        public OrderState Estado { get; private set; }
        public decimal Total { get; private set; }
        public DateTime Timestamp { get; init; }

        public Order(Guid id, Guid foodTruckId, IEnumerable<Item> items)
        {
            Id = id;
            FoodTruckId = foodTruckId;
            Items.AddRange(items);
            Estado = OrderState.Creada;
            Timestamp = DateTime.UtcNow;
            RecalcularTotal();
        }

        public void RecalcularTotal()
        {
            Total = Items.Sum(i => i.Precio * i.Cantidad);
        }

        public (OrderState anterior, OrderState nuevo) CambiarEstado(OrderState nuevo)
        {
            var anterior = Estado;
            Estado = nuevo;
            return (anterior, nuevo);
        }
    }

    public class EventLog
    {
        public Guid OrderId { get; init; }
        public OrderState EstadoAnterior { get; init; }
        public OrderState EstadoNuevo { get; init; }
        public DateTime Fecha { get; init; }

        public EventLog(Guid orderId, OrderState anterior, OrderState nuevo)
        {
            OrderId = orderId;
            EstadoAnterior = anterior;
            EstadoNuevo = nuevo;
            Fecha = DateTime.UtcNow;
        }
    }
}
