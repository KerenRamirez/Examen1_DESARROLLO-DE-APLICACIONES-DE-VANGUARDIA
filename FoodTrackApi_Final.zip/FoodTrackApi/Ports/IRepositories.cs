using System;
using System.Collections.Generic;
using FoodTrack.Domain;

namespace FoodTrack.Ports
{
    public interface IFoodTruckRepository
    {
        void Add(FoodTruck truck);
        FoodTruck? Get(Guid id);
        IEnumerable<FoodTruck> ListAll();
    }

    public interface IOrderRepository
    {
        void Add(Order order);
        Order? Get(Guid id);
        void Update(Order order);
        IEnumerable<Order> ListByFoodTruck(Guid foodTruckId);
    }

    public interface IEventLogRepository
    {
        void Add(EventLog log);
        IEnumerable<EventLog> GetForOrder(Guid orderId);
        IEnumerable<EventLog> ListAll();
    }
}
