using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using FoodTrack.Domain;
using FoodTrack.Ports;
using FoodTrack.Adapters.InMemory;
using FoodTrack.Application;

var builder = WebApplication.CreateBuilder(args);
builder.Services.Configure<JsonOptions>(opts =>
{
    opts.SerializerOptions.PropertyNamingPolicy = null;
});

// Repositories (in-memory)
builder.Services.AddSingleton<IFoodTruckRepository, InMemoryFoodTruckRepository>();
builder.Services.AddSingleton<IOrderRepository, InMemoryOrderRepository>();
builder.Services.AddSingleton<IEventLogRepository, InMemoryEventLogRepository>();

// Application services
builder.Services.AddSingleton<OrderService>();

var app = builder.Build();

app.MapGet("/", () => Results.Ok(new { Service = "FoodTrack API", Version = "1.0" }));

// FoodTrucks
app.MapPost("/foodtrucks", (CreateFoodTruckDto dto, IFoodTruckRepository repo) =>
{
    var truck = new FoodTruck(Guid.NewGuid(), dto.Nombre, dto.UbicacionActual);
    repo.Add(truck);
    return Results.Created($"/foodtrucks/{truck.Id}", truck);
});

app.MapGet("/foodtrucks", (IFoodTruckRepository repo) => Results.Ok(repo.ListAll()));

// Orders
app.MapPost("/orders", (CreateOrderDto dto, OrderService service) =>
{
    var items = dto.Items.Select(i => new Item(i.Nombre, i.Precio, i.Cantidad));
    var order = service.CreateOrder(dto.FoodTruckId, items);
    return Results.Created($"/orders/{order.Id}", order);
});

app.MapGet("/orders/{id:guid}", (Guid id, OrderService service) =>
{
    var order = service.GetOrder(id);
    return order is null ? Results.NotFound() : Results.Ok(order);
});

app.MapPut("/orders/{id:guid}/state", (Guid id, ChangeStateDto dto, OrderService service) =>
{
    try
    {
        if (!Enum.TryParse<OrderState>(dto.Estado, true, out var nuevo)) return Results.BadRequest("Estado inválido.");
        service.ChangeOrderState(id, nuevo);
        return Results.NoContent();
    }
    catch (ArgumentException ex) { return Results.NotFound(new { error = ex.Message }); }
});

app.MapGet("/foodtrucks/{id:guid}/orders", (Guid id, OrderService service) =>
{
    var orders = service.ListOrdersForFoodTruck(id);
    return Results.Ok(orders);
});

app.MapGet("/orders/{id:guid}/events", (Guid id, OrderService service) =>
{
    var events = service.GetEventLogForOrder(id);
    return Results.Ok(events);
});

app.Run();

// DTOs local to Program for simplicity
public record CreateFoodTruckDto(string Nombre, string UbicacionActual);
public record CreateOrderDto(Guid FoodTruckId, IEnumerable<CreateItemDto> Items);
public record CreateItemDto(string Nombre, decimal Precio, int Cantidad);
public record ChangeStateDto(string Estado);
