# FoodTrack API - Proyecto Final
Incluye:
- API .NET completa con arquitectura por capas
- Repositorios en memoria
- Dockerfile listo para build y run

## Ejecución local
dotnet run

## Docker
docker build -t foodtrackapi .
docker run -p 5000:8080 foodtrackapi
