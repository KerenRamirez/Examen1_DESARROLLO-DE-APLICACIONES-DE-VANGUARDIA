using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using FoodTrack.Domain;
using FoodTrack.Ports;

namespace FoodTrack.Adapters.InMemory
{
    public class InMemoryFoodTruckRepository : IFoodTruckRepository
    {
        private readonly ConcurrentDictionary<Guid, FoodTruck> _store = new();
        public void Add(FoodTruck truck) => _store[truck.Id] = truck;
        public FoodTruck? Get(Guid id) => _store.TryGetValue(id, out var t) ? t : null;
        public IEnumerable<FoodTruck> ListAll() => _store.Values;
    }

    public class InMemoryOrderRepository : IOrderRepository
    {
        private readonly ConcurrentDictionary<Guid, Order> _store = new();
        public void Add(Order order) => _store[order.Id] = order;
        public Order? Get(Guid id) => _store.TryGetValue(id, out var o) ? o : null;
        public void Update(Order order) => _store[order.Id] = order;
        public IEnumerable<Order> ListByFoodTruck(Guid foodTruckId) => _store.Values.Where(o => o.FoodTruckId == foodTruckId);
    }

    public class InMemoryEventLogRepository : IEventLogRepository
    {
        private readonly List<EventLog> _logs = new();
        private readonly object _lock = new();
        public void Add(EventLog log) { lock (_lock) { _logs.Add(log); } }
        public IEnumerable<EventLog> GetForOrder(Guid orderId) => _logs.Where(l => l.OrderId == orderId);
        public IEnumerable<EventLog> ListAll() => _logs.AsReadOnly();
    }
}
